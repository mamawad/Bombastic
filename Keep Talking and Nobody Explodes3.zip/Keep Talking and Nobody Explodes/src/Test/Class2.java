package Test;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.event.*;

public class Class2 extends Class1 {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Button bt = new Button("Class2");
        Scene scene = new Scene(new Pane(bt),400,400);
        primaryStage.setScene(scene);
        bt.setOnAction(e->{
            super.start(primaryStage);
        });
    }
}
