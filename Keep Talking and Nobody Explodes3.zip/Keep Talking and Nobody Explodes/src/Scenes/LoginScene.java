//2:34:16
package Scenes;

import Resources.*;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.image.*;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;

public class LoginScene extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    Pane root = new Pane();
    Person person1 = new Person(null,null,0);
    Person person2 = new Person(null,null,0);;

    @Override
    public void init(){
        int y = 200;
        Text userPrompt1 = new Text("Username: ");      userPrompt1.getStyleClass().add("LoginText");
        Text passPrompt1 = new Text("Password: ");      passPrompt1.getStyleClass().add("LoginText");
        userPrompt1.setFill(Color.WHITE);   passPrompt1.setFill(Color.WHITE);
        VBox person1Login = new VBox(5);
        person1Login.getStyleClass().add("LoginPrompt");
        TextField person1T = new TextField();           person1T.getStyleClass().add("TextFields");     person1T.setPromptText("Username");
        PasswordField person1P = new PasswordField();   person1P.getStyleClass().add("TextFields");     person1P.setPromptText("Password");
        Button login1 = new Button("Login");                    login1.getStyleClass().add("ButtonLogin");
        Button createacc1 = new Button("Create Account");       createacc1.getStyleClass().add("ButtonCreate");
        person1Login.getChildren().addAll(userPrompt1,person1T,passPrompt1,person1P,login1,createacc1);
        person1Login.setLayoutX(ScreenSpecs.screenWidth/4.0);person1Login.setLayoutY(ScreenSpecs.screenHeight/2.0 + y);

        Text userPrompt2 = new Text("Username: ");      userPrompt2.getStyleClass().add("LoginText");
        Text passPrompt2 = new Text("Password: ");      passPrompt2.getStyleClass().add("LoginText");
        userPrompt2.setFill(Color.WHITE);   passPrompt2.setFill(Color.WHITE);
        VBox person2Login = new VBox(5);
        person2Login.getStyleClass().add("LoginPrompt");
        TextField person2T = new TextField();           person2T.getStyleClass().add("TextFields");     person2T.setPromptText("Username");
        PasswordField person2P = new PasswordField();   person2P.getStyleClass().add("TextFields");     person2P.setPromptText("Password");
        Button login2 = new Button("Login");  login2.setDisable(true);  login2.getStyleClass().add("ButtonLogin");
        Button createacc2 = new Button("Create Account");       createacc2.getStyleClass().add("ButtonCreate"); createacc2.setDisable(true);
        person2Login.getChildren().addAll(userPrompt2,person2T,passPrompt2,person2P,login2,createacc2);

        person2Login.setLayoutX(ScreenSpecs.screenWidth/2  + ScreenSpecs.screenWidth/4.0 - 100);
        person2Login.setLayoutY(ScreenSpecs.screenHeight/2 + y);

        ImageView background = new ImageView(new Image("file:C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Photos\\Background3u.jpg"));
        background.setFitHeight(ScreenSpecs.screenHeight);
        background.setFitWidth(ScreenSpecs.screenWidth);
        root.getChildren().addAll(background,person1Login,person2Login);


        //ACTIONS


        login1.setOnAction(e ->{
            person1 = Person.checkLogin(person1T.getText(),person1P.getText());
            if(person1 != null && !person1.username.equals(person2.username)){
                Text text = new Text("Logged in Succesfully \n Waiting for Player 2"); text.setY(200); text.setX(30);
                ImageView imageView = new ImageView(new Image("file:C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Photos\\CheckMark.png"));
                imageView.setY(-30); text.getStyleClass().add("LoginX"); text.setFill(Color.GREEN);
                text.setStyle("-fx-font-size: 16px; -fx-font-color: green; -fx-font-weight: bold;");
                Pane pane = new Pane(); pane.getChildren().addAll(imageView,text); pane.getStylesheets().add("Styles/LoginStyles.css");
                person1Login.getChildren().removeAll(userPrompt1, person1T, passPrompt1, person1P, login1, createacc1);
                person1Login.getChildren().add(pane);   login2.setDisable(false);  createacc2.setDisable(false);
            }
        });
        createacc1.setOnAction(e -> {
            if (Person.checkUsername(person1T.getText()) == false && !(person1T.getText().equals("")) && !(person1T.getText().equals(""))) {
                person1 = Person.createAcc(person1T.getText(), person1P.getText());
                if (person1 != null) {
                    person1Login.getChildren().removeAll(userPrompt1, person1T, passPrompt1, person1P, login1, createacc1);
                    ImageView imageView = new ImageView(new Image("file:C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Photos\\BlueCheckMark.png"));
                    Text text = new Text(person1.username + " is Ready");
                    text.setFill(Color.BLUE); text.setX(40);
                    text.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 18));
                    Pane pane = new Pane(); pane.getChildren().add(text);
                    person1Login.getChildren().addAll(imageView, pane); login2.setDisable(false);   createacc2.setDisable(false);
                }
            } else {
                Text text = new Text("Username already Taken");
                text.setFill(Color.RED);    text.setY(25);
                text.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 18));
                Button btn = new Button("Try Again");
                btn.getStyleClass().add("ButtonX"); btn.getStylesheets().add("Styles/LoginStyles.css"); btn.setLayoutY(50);
                ImageView imageView = new ImageView(new Image("file:C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Photos\\RedX.png"));
                imageView.setFitWidth(100); imageView.setFitHeight(100);
                Pane pane = new Pane();
                pane.getChildren().addAll(text, btn);
                person1Login.getChildren().removeAll(userPrompt1, person1T, passPrompt1, person1P, login1, createacc1);
                person1Login.getChildren().addAll(imageView, pane);
                btn.setOnAction(f -> {
                    person1Login.getChildren().removeAll(imageView, pane);
                    person1Login.getChildren().addAll(userPrompt1, person1T, passPrompt1, person1P, login1, createacc1);
                });
            }
        });
        login2.setOnAction(e ->{
            person2 = Person.checkLogin(person2T.getText(),person2P.getText());
            if(person2 != null && !person1.username.equals(person2.username)){
                Text text = new Text("Logged in Succesfully \n Waiting for Player 1"); text.setY(200); text.setX(30);
                ImageView imageView = new ImageView(new Image("file:C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Photos\\CheckMark.png"));
                imageView.setY(-30); text.getStyleClass().add("LoginX"); text.setFill(Color.GREEN);
                text.setStyle("-fx-font-size: 16px; -fx-font-color: green; -fx-font-weight: bold;");
                Pane pane = new Pane(); pane.getChildren().addAll(imageView,text); pane.getStylesheets().add("Styles/LoginStyles.css");
                person2Login.getChildren().removeAll(userPrompt2, person2T, passPrompt2, person2P, login2, createacc2);
                person2Login.getChildren().add(pane);
                System.out.println(person1.username);
                System.out.println(person2.username);
            }
        });
        createacc2.setOnAction(e -> {
            if (Person.checkUsername(person2T.getText()) == false && !(person2T.getText().equals("")) && !(person2P.getText().equals(""))){
                person2 = Person.createAcc(person2T.getText(), person2P.getText());
                if (person2 != null) {
                    person2Login.getChildren().removeAll(userPrompt2, person2T, passPrompt2, person2P, login2, createacc2);
                    ImageView imageView = new ImageView(new Image("file:C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Photos\\BlueCheckMark.png"));
                    Text text = new Text(person2.username + " is Ready");
                    text.setFill(Color.BLUE);   text.setX(40);
                    text.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 18));
                    Pane pane = new Pane(); pane.getChildren().add(text);
                    person2Login.getChildren().addAll(imageView, pane);
                }
            } else {
                Text text = new Text("Username already Taken");
                text.setFill(Color.RED);    text.setY(25);
                text.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 18));
                Button btn = new Button("Try Again");
                btn.getStyleClass().add("ButtonX"); btn.getStylesheets().add("Styles/LoginStyles.css"); btn.setLayoutY(50);
                ImageView imageView = new ImageView(new Image("file:C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Photos\\RedX.png"));
                imageView.setFitWidth(100); imageView.setFitHeight(100);
                Pane pane = new Pane(); pane.getChildren().addAll(text, btn);
                person2Login.getChildren().removeAll(userPrompt2, person2T, passPrompt2, person2P, login2, createacc2);
                person2Login.getChildren().addAll(imageView, pane);
                btn.setOnAction(f -> {
                    person2Login.getChildren().removeAll(imageView, pane);
                    person2Login.getChildren().addAll(userPrompt2, person2T, passPrompt2, person2P, login2, createacc2);
                });
            }
        });
    }


    @Override
    public void start(Stage primaryStage) {
        MainScene ms = new MainScene();
        Scene loginScene = new Scene(root, ScreenSpecs.screenWidth,ScreenSpecs.screenHeight);
        root.getStylesheets().add("Styles/LoginStyles.css");
        root.getStyleClass().add("LoginRoot");
        primaryStage.setScene(loginScene);
        primaryStage.show();
        primaryStage.setResizable(false);
        MainScene.primaryStage = primaryStage;

    }
}

