package Scenes;

import Resources.*;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.image.*;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.control.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;



public class MainScene extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    public static Stage primaryStage;
    Pane root = new Pane();

    @Override
    public void init(){
        MenuScene menuScene = new MenuScene();

        ImageView mainbg = new ImageView();
        mainbg.setImage(new Image("file:src/Photos/MainMenu.png"));
        mainbg.setFitHeight(ScreenSpecs.screenHeight + 10);
        mainbg.setFitWidth(ScreenSpecs.screenWidth+ 10);

        //Menu
        Pane menuPolyP = new Pane();
        Polygon menuPoly = new Polygon(48,23,134,27,215,38,233,45,235,56,257,65,273,104,
                257,111,272,173,262,178,57,138);
        menuPolyP.setLayoutX(1340); menuPolyP.setLayoutY(557);   menuPoly.setFill(Color.TRANSPARENT);
        menuPolyP.getChildren().addAll(menuPoly);   menuPoly.setStrokeWidth(5);

        menuPolyP.setOnMouseEntered(e ->{ menuPoly.setStroke(Color.YELLOW);
            menuPoly.setOnMouseExited(f -> menuPoly.setStroke(Color.TRANSPARENT));
            menuPoly.setOnMouseClicked(g -> menuScene.start(MainScene.primaryStage)); });     // <------ something to add here

        //Bomb
        Pane bombP = new Pane();
        Polygon bombPoly = new Polygon(846,523,1039,532,1053,725,826,720);
        bombPoly.setFill(Color.TRANSPARENT); bombPoly.setLayoutY(-40);
        bombP.getChildren().add(bombPoly);  bombPoly.setStrokeWidth(9);

        bombPoly.setOnMouseEntered(e -> { bombPoly.setStroke(Color.YELLOW);
            bombPoly.setOnMouseExited(f -> bombPoly.setStroke(Color.TRANSPARENT));
            bombPoly.setOnMouseClicked(g -> System.out.println("CLICKED"));         //  <----- something to add here
        });










        root.getChildren().addAll(mainbg,menuPolyP,bombPoly);
    }

    @Override
    public void start(Stage primaryStage) {
        this.init();
        root.getStylesheets().add("Styles/MainStyles.css");

        Scene scene = new Scene(root, ScreenSpecs.screenWidth,ScreenSpecs.screenHeight);
        primaryStage.setScene(scene);
        primaryStage.setTitle(null);
        primaryStage.show();

    }
}
