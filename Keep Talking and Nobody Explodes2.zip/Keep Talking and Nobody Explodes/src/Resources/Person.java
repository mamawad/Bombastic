package Resources;

import java.io.*;

public class Person {
    public String username;
    private String password;
    public int level;

    public Person(String username,String password, int level){
        this.username = username;
        this.password = password;
        this.level = 0;
    }

    public String getPassword(){
        return this.password;
    }

    public static Person checkLogin(String username, String password) {
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader("C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Resources\\Account.txt"));
            String line;
            String[] arr;
            while ((line = bufferedReader.readLine()) != null) {
                line.trim();
                arr = line.split(" ");
                if(arr[0].compareToIgnoreCase(username) == 0){
                    if(arr[1].compareTo(password) == 0){
                        return new Person(username,password,Integer.parseInt(arr[2]));
                    }
                }
            }
            bufferedReader.close();
        }
        catch (Exception e){
            System.out.println(e);
        }
        return null;
    }

    public static boolean checkUsername(String username){
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader("C:\\Users\\majda\\Desktop\\SE220 Project\\Keep Talking and Nobody Explodes\\src\\Resources\\Account.txt"));
            String line;
            String[] arr;
            while ((line = bufferedReader.readLine()) != null) {
                line.trim();
                arr = line.split(" ");
                if(arr[0].compareToIgnoreCase(username) == 0){
                    return true;
                }
            }
            bufferedReader.close();
        }
        catch (Exception e){
            System.out.println(e);
        }
        return false;
    }


    public static Person createAcc(String username, String password) {
        BufferedWriter bufferedWriter = null;
        try {
            bufferedWriter = new BufferedWriter(new FileWriter("C:\\\\Users\\\\majda\\\\Desktop\\\\SE220 Project\\\\Keep Talking and Nobody Explodes\\\\src\\\\Resources\\\\Account.txt",true));
            String line = username + " " + password + " " + "1\n";
            bufferedWriter.append(line);
            bufferedWriter.close();
            return new Person(username,password,1);
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    public static void main(String[] args) {
        System.out.println(Person.createAcc("Moussa", "hame"));


    }
}
