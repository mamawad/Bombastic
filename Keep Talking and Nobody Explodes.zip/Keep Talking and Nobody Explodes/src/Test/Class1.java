package Test;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.event.*;

public class Class1 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Class2 class2 = new Class2();
        PasswordField pf = new PasswordField();

        Button bt = new Button("Class1");
        Scene scene = new Scene(new Pane(pf,bt),500,500);
        primaryStage.setScene(scene);
        primaryStage.show();

        bt.setOnAction(e ->{
            System.out.print(pf.getText().equals(""));
        });
    }
}
