package Resources;

public class ScreenSpecs {
    public static final double screenWidth = javafx.stage.Screen.getPrimary().getBounds().getWidth();
    public static final double screenHeight = javafx.stage.Screen.getPrimary().getBounds().getHeight() - 72;;
}
