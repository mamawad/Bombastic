import javafx.application.Application;
import javafx.scene.image.*;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.paint.*;
import java.io.File;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.event.*;

public class MainScreen extends Application {

    public static void main(String[] args) {
        launch(args);
    }


    public double screenWidth;
    public double screenHeight;
    public double taskbarHeight = 72;

    String mainBackground = "file:src/Photos/MainMenu.png";




    @Override
    public void init(){
    screenWidth = Screen.getPrimary().getBounds().getWidth();
    screenHeight = Screen.getPrimary().getBounds().getHeight() - taskbarHeight;
    }

    @Override
    public void start(Stage primaryStage) {

        ImageView mainbg = new ImageView();
        mainbg.setImage(new Image(mainBackground));
        mainbg.setX(0);
        mainbg.setY(0);
        mainbg.setFitWidth(screenWidth);
        mainbg.setFitHeight(screenHeight);
        
        Pane root = new Pane();
        root.getChildren().add(mainbg);

        Scene scene = new Scene(root,screenWidth,screenHeight);
        primaryStage.setScene(scene);
        primaryStage.setTitle(null);
        primaryStage.setResizable(false);
        primaryStage.setAlwaysOnTop(true);
        primaryStage.show();
    }
}
