package Scenes;

import Resources.ScreenSpecs;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.input.MouseButton;
import javafx.stage.Stage;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.util.Duration;

public class OptionsScene extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    Pane root = new Pane();
    MainScene ms = new MainScene();
    ImageView bg = new ImageView(new Image("file:src/Photos/Menu.png"));
    @Override
    public void init(){
        Pane menu1 = new Pane(); Pane menus1 = new Pane();

        Text text = new Text(""); text.getStyleClass().add("MenuText");
        text.setX(1050); text.setY(250);
        ListView listView = new ListView();    listView.getStyleClass().add("ListViewOptions");
        listView.getItems().addAll("Sound","Graphis","Accessibility","Credits");
        menus1.getChildren().addAll(listView);  listView.setLayoutX(950);   listView.setLayoutY(300);
        Rectangle rect1 = new Rectangle(950,300,500,70); rect1.getStyleClass().add("Rects");
        Rectangle rect2 = new Rectangle(950,370,500,70); rect2.getStyleClass().add("Rects");
        Rectangle rect3 = new Rectangle(950,440,500,70); rect3.getStyleClass().add("Rects");
        Rectangle rect4 = new Rectangle(950,510,500,70); rect4.getStyleClass().add("Rects");
        rect1.setOnMouseEntered(e -> {
            rect1.setFill(Color.rgb(245, 218, 7,0.6));
            rect1.setOnMouseExited(f -> {rect1.setFill(Color.TRANSPARENT);});
        });
        rect2.setOnMouseEntered(e -> {
            rect2.setFill(Color.rgb(245, 218, 7,0.6));
            rect2.setOnMouseExited(f -> {rect2.setFill(Color.TRANSPARENT);});
        });
        rect3.setOnMouseEntered(e -> {
            rect3.setFill(Color.rgb(245, 218, 7,0.6));
            rect3.setOnMouseExited(f -> {rect3.setFill(Color.TRANSPARENT);});
        });
        rect4.setOnMouseEntered(e -> {
            rect4.setFill(Color.rgb(245, 218, 7,0.6));
            rect4.setOnMouseExited(f -> {rect4.setFill(Color.TRANSPARENT);});
        });

        menu1.getChildren().addAll(bg,menus1,text,rect1,rect2,rect3,rect4);

        listView.setCellFactory(param -> {
            javafx.scene.control.ListCell<String> cell = new javafx.scene.control.ListCell<String>() {
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {setText(null);} else {setText(item); setStyle("-fx-background-color: transparent;" +
                            "-fx-text-fill: black");}}};
            cell.setAlignment(Pos.CENTER);return cell;});

        listView.setOnMouseClicked(e->{
            if(listView.getSelectionModel().getSelectedItem() == "Options"){
                System.out.println("Options");
            }
            else if(listView.getSelectionModel().getSelectedItem() == "Language"){
                System.out.println("Language");
            }
            else{
                try {stop();}catch (Exception f){}
            }
        });
        String[] arr = {"O","p","t","i","o","n","s"};
        int[] index = {0};
        PauseTransition pause = new PauseTransition(Duration.seconds(0.3));
        pause.play();
        pause.setOnFinished(e ->{
            if(index[0] < arr.length){
                text.setText(text.getText()+arr[index[0]]);
                index[0]++; pause.play();
            }
        });

        Tab menuT1 = new Tab();
        menuT1.setContent(menu1);


        // New Tab

        TabPane tp = new TabPane(); tp.setSide(Side.BOTTOM);
        tp.getTabs().addAll(menuT1);
        root.getChildren().addAll(tp);

        tp.setOnMouseClicked(e ->{
            if (e.getButton() == MouseButton.SECONDARY){
                MenuScene menuScene = new MenuScene();
                menuScene.start(MainScene.primaryStage);
            }
        });

    }

    @Override
    public void start(Stage primaryStage) {
        init();
        Scene scene = new Scene(root, ScreenSpecs.screenWidth,ScreenSpecs.screenHeight);
        scene.getStylesheets().add("Styles/MainStyles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
        MainScene.primaryStage = primaryStage;
    }

}
