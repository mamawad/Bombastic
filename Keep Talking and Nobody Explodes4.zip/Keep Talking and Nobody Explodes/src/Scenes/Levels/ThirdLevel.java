package Scenes.Levels;

import Resources.ScreenSpecs;
import Scenes.BombBookScene;
import Scenes.MainScene;
import javafx.application.Application;
import javafx.scene.image.*;
import javafx.scene.input.MouseButton;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;

public class ThirdLevel extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    Pane root = new Pane();

    @Override
    public void init(){
        ImageView bg = new ImageView(new Image("file:src/Photos/ThirdLevel.png"));
        bg.setFitWidth(ScreenSpecs.screenWidth); bg.setFitHeight(ScreenSpecs.screenHeight);

        Pane buttons = new Pane();
        Text identifier = new Text("Water You Talking About?"); identifier.setX(950);
        identifier.setY(222); identifier.getStyleClass().add("LevelTitle");
        Polygon back = new Polygon(963,737,1081,736,1083,783,964,785);  back.setFill(Color.TRANSPARENT);
        Polygon start = new Polygon(1127,736,1269,736,1270,785,1130,783);   start.setFill(Color.TRANSPARENT);
        buttons.getChildren().addAll(back,start);   buttons.setLayoutY(-50);    back.setStrokeWidth(7);
        back.setOnMouseEntered(e -> { back.setStroke(Color.YELLOW);
            back.setOnMouseExited(f -> {back.setStroke(Color.TRANSPARENT);});});    start.setStrokeWidth(7);
        start.setOnMouseEntered(e -> { start.setStroke(Color.YELLOW);
            start.setOnMouseExited(f -> {start.setStroke(Color.TRANSPARENT);});});


        root.getChildren().addAll(bg, buttons, identifier);

        BombBookScene bbs = new BombBookScene();
        back.setOnMouseClicked(e-> {
            if(e.getButton() == MouseButton.PRIMARY){
                bbs.start(MainScene.primaryStage);
            }
        });
    }

    @Override
    public void start(Stage primaryStage) {
        init();
        Scene scene = new Scene(root, ScreenSpecs.screenWidth,ScreenSpecs.screenHeight);
        scene.getStylesheets().add("Styles/MainStyles.css");
        primaryStage.setScene(scene);
        primaryStage.show();
        MainScene.primaryStage = primaryStage;
    }
}
