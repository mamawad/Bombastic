package Scenes;

import Resources.ScreenSpecs;
import Scenes.Levels.FirstLevel;
import Scenes.Levels.SecondLevel;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.scene.input.MouseButton;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.shape.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;


public class BombBookScene extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    Pane root = new Pane();

    @Override
    public void init(){
        ImageView bg = new ImageView(new Image("file:src/Photos/BombBook.png"));
        bg.setFitWidth(ScreenSpecs.screenWidth); bg.setFitHeight(ScreenSpecs.screenHeight);

        Text text1 = new Text("1: What's A Bomb?"); text1.getStyleClass().add("BombBookText");
        Text text2 = new Text("2: The First Bomb"); text2.getStyleClass().add("BombBookText");
        Text text3 = new Text("3: Water you Saying?"); text3.getStyleClass().add("BombBookText");
        Text text4 = new Text("4: Stop Dashing Around"); text4.getStyleClass().add("BombBookText");
        VBox textV = new VBox(20);    textV.getChildren().addAll(text1,text2,text3,text4);
        textV.setLayoutX(925); textV.setLayoutY(300);
        Rectangle rect1 = new Rectangle(400,35);    rect1.setFill(Color.TRANSPARENT);
        Rectangle rect2 = new Rectangle(400,35);    rect2.setFill(Color.TRANSPARENT);
        Rectangle rect3 = new Rectangle(400,35);    rect3.setFill(Color.TRANSPARENT);
        Rectangle rect4 = new Rectangle(400,35);    rect4.setFill(Color.TRANSPARENT);
        VBox rectV = new VBox(15);    rectV.getChildren().addAll(rect1,rect2,rect3,rect4);
        rectV.setLayoutX(925);  rectV.setLayoutY(300);
        rect1.setOnMouseEntered(e -> { rect1.setFill(Color.rgb(245, 218, 7,0.7));
        rect1.setOnMouseExited(f ->{ rect1.setFill(Color.TRANSPARENT);});});
        rect2.setOnMouseEntered(e -> { rect2.setFill(Color.rgb(245, 218, 7,0.7));
        rect2.setOnMouseExited(f ->{ rect2.setFill(Color.TRANSPARENT);});});
        rect3.setOnMouseEntered(e -> { rect3.setFill(Color.rgb(245, 218, 7,0.7));
        rect3.setOnMouseExited(f ->{ rect3.setFill(Color.TRANSPARENT);});});
        rect4.setOnMouseEntered(e -> { rect4.setFill(Color.rgb(245, 218, 7,0.7));
        rect4.setOnMouseExited(f ->{ rect4.setFill(Color.TRANSPARENT);});});
        Polygon back = new Polygon(963,737,1081,736,1083,783,964,785); back.setFill(Color.TRANSPARENT);
        back.setLayoutY(-57); back.setLayoutX(85);
        back.setOnMouseEntered(e -> { back.setStroke(Color.YELLOW);
            back.setOnMouseExited(f -> {back.setStroke(Color.TRANSPARENT);});
            back.setOnMouseClicked(g -> {
                if(g.getButton() == MouseButton.PRIMARY){
                    MainScene ms = new MainScene(); ms.start(MainScene.primaryStage);
                }
            });});    back.setStrokeWidth(7);
        root.getChildren().addAll(bg,textV,rectV,back);

        rect2.setOnMouseClicked(e ->{
            if(e.getButton() == MouseButton.PRIMARY){
                FirstLevel fl = new FirstLevel();
                fl.start(MainScene.primaryStage);
            }
        });
        rect3.setOnMouseClicked(e ->{
            if(e.getButton() == MouseButton.PRIMARY){
                SecondLevel sl = new SecondLevel();
                sl.start(MainScene.primaryStage);
            }
        });
        rect4.setOnMouseClicked(e ->{
            if(e.getButton() == MouseButton.PRIMARY){
                SecondLevel sl = new SecondLevel();
                sl.start(MainScene.primaryStage);
            }
        });
    }

    @Override
    public void start(Stage primaryStage) {
        init();
        Scene scene = new Scene(root, ScreenSpecs.screenWidth,ScreenSpecs.screenHeight);
        primaryStage.setScene(scene);   scene.getStylesheets().add("Styles/MainStyles.css");
        primaryStage.show();
        MainScene.primaryStage = primaryStage;
    }
}
