package Resources;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class LeaderBoard {
    String person1;
    String person2;
    double time;
    public LeaderBoard(String person1, String person2, double time){
        this.person1 = person1;
        this.person2 = person2;
        this.time = time;
    }

    public static int count1 = 0;
    public static int count2 = 0;
    public static int count3 = 0;

    public static void addToCount(int num){
        BufferedReader bufferedReader;  BufferedWriter bufferedWriter;
        setCounts();
        String line = "";   String templine;    String[] temparr;
        int temp;   String add;
        try{
            switch (num) {
                case 1:
                    bufferedReader = new BufferedReader(new FileReader("src/Resources/Counts.txt"));
                    while ((templine = bufferedReader.readLine()) != null) {
                        line = templine;
                    }
                    temparr = line.trim().split(" ");
                    bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/Counts.txt"));
                    temp = Integer.parseInt(temparr[0]);
                    add = ++temp + " " + temparr[1] + " " + temparr[2];
                    bufferedWriter.write(add);  bufferedWriter.newLine();   bufferedWriter.close();
                    break;
                case 2:
                    bufferedReader = new BufferedReader(new FileReader("src/Resources/Counts.txt"));
                    while ((templine = bufferedReader.readLine()) != null) {
                        line = templine;
                    }
                    temparr = line.trim().split(" ");
                    bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/Counts.txt"));
                    temp = Integer.parseInt(temparr[1]);
                    add = temparr[0] + " " + ++temp + " " + temparr[2];
                    bufferedWriter.write(add);  bufferedWriter.newLine();   bufferedWriter.close();
                    break;
                case 3:
                    bufferedReader = new BufferedReader(new FileReader("src/Resources/Counts.txt"));
                    while ((templine = bufferedReader.readLine()) != null) {
                        line = templine;
                    }
                    temparr = line.trim().split(" ");
                    bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/Counts.txt"));
                    temp = Integer.parseInt(temparr[2]);
                    add = temparr[0] + " " + temparr[1] + " " + ++temp ;
                    bufferedWriter.write(add);  bufferedWriter.newLine();   bufferedWriter.close();
                    break;
            }
        }
        catch (Exception e){
            System.out.println(e);
        }

    }

    public static void setCounts(){
        String templine;
        String line ="";
        try{
            BufferedReader bufferedReader = new BufferedReader(new FileReader("src/Resources/Counts.txt"));
            while((templine= bufferedReader.readLine()) != null){line = templine;}
            String[] temp = line.trim().split(" ");
            count1 = Integer.parseInt(temp[0]);
            count2 = Integer.parseInt(temp[1]);
            count3 = Integer.parseInt(temp[2]);
            bufferedReader.close();
        }
        catch (Exception e){
            System.out.println(e);
        }
    }

    public static String[][] getLeaderBoard(int num){
        sortLeaderBoard(num);
        BufferedReader bufferedReader = null;
        String[][] leaderboard =new String[10][10];
        String line;
        String[] arr;
        try{
            switch (num){
                case 1:
                bufferedReader = new BufferedReader(new FileReader("src/Resources/LeaderBoard1.txt"));
                for(int i = 0; i < 10 && (line = bufferedReader.readLine()) != null; i++){
                    line.trim();
                    arr = line.split(" ");
                    leaderboard[i] = arr;
                }   break;
                case 2:
                    bufferedReader = new BufferedReader(new FileReader("src/Resources/LeaderBoard2.txt"));
                    for(int i = 0; i < 10 && (line = bufferedReader.readLine()) != null; i++){
                        line.trim();
                        arr = line.split(" ");
                        leaderboard[i] = arr;
                    }   break;
                case 3:
                    bufferedReader = new BufferedReader(new FileReader("src/Resources/LeaderBoard3.txt"));
                    for(int i = 0; i < 10 && (line = bufferedReader.readLine()) != null; i++){
                        line.trim();
                        arr = line.split(" ");
                        leaderboard[i] = arr;
                    }   break;
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
        return leaderboard;
    }
    public static void addToLeaderBoard(int num,String username1,String username2,double time){
        BufferedWriter bufferedWriter = null;
        String line;
        try{
            switch (num){
                case 1:
                    bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard1.txt",true));
                    line = username1 + " " + username2 + " " + time;
                    bufferedWriter.write(line);
                    bufferedWriter.newLine(); addToCount(1);
                    break;
                case 2:
                    bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard2.txt",true));
                    line = username1 + " " + username2 + " " + time;
                    bufferedWriter.write(line);
                    bufferedWriter.newLine();   addToCount(2);
                    break;
                case 3:
                    bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard3.txt",true));
                    line = username1 + " " + username2 + " " + time;
                    bufferedWriter.write(line);
                    bufferedWriter.newLine();   addToCount(3);
                    break;
            }   bufferedWriter.close();
        }
        catch (Exception e){
            System.out.println(e);
        }
    }


    private static void sortLeaderBoard(int num) {
        BufferedWriter bufferedWriter = null;
        BufferedReader bufferedReader = null;
        String temp;
        String[] temparr;

        try {
            if (num == 1) {
                List<String[]> records = new ArrayList<>();
                bufferedReader = new BufferedReader(new FileReader("src/Resources/LeaderBoard1.txt"));
                while ((temp = bufferedReader.readLine()) != null) {
                    temparr = temp.trim().split(" ");
                    records.add(temparr);
                }
                records.sort((record1, record2) -> {
                    double age1 = Double.parseDouble(record1[2]);
                    double age2 = Double.parseDouble(record2[2]);
                    return Double.compare(age1, age2);
                });
                bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard1.txt",false)); bufferedWriter.write(""); bufferedWriter.close();
                bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard1.txt",true));
                for (String[] record : records) {
                    bufferedWriter.write(String.join(" ", record));
                    bufferedWriter.newLine();
                }
                File originalFile = new File("src/Resources/LeaderBoard1.txt");
                File sortedFile = new File("src/Resources/temp.txt");
                if (originalFile.delete()) {
                    sortedFile.renameTo(originalFile);
                }
            }
            if (num == 2) {
                List<String[]> records = new ArrayList<>();
                bufferedReader = new BufferedReader(new FileReader("src/Resources/LeaderBoard2.txt"));
                while ((temp = bufferedReader.readLine()) != null) {
                    temparr = temp.trim().split(" ");
                    records.add(temparr);
                }
                records.sort((record1, record2) -> {
                    double age1 = Double.parseDouble(record1[2]);
                    double age2 = Double.parseDouble(record2[2]);
                    return Double.compare(age1, age2);
                });
                bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard2.txt",false)); bufferedWriter.write(""); bufferedWriter.close();
                bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard2.txt",true));
                for (String[] record : records) {
                    bufferedWriter.write(String.join(" ", record));
                    bufferedWriter.newLine();
                }
                File originalFile = new File("src/Resources/LeaderBoard2.txt");
                File sortedFile = new File("src/Resources/temp.txt");
                if (originalFile.delete()) {
                    sortedFile.renameTo(originalFile);
                }
            }
            if (num == 3) {
                List<String[]> records = new ArrayList<>();
                bufferedReader = new BufferedReader(new FileReader("src/Resources/LeaderBoard3.txt"));
                while ((temp = bufferedReader.readLine()) != null) {
                    temparr = temp.trim().split(" ");
                    records.add(temparr);
                }
                records.sort((record1, record2) -> {
                    double age1 = Double.parseDouble(record1[2]);
                    double age2 = Double.parseDouble(record2[2]);
                    return Double.compare(age1, age2);
                });
                bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard3.txt",false)); bufferedWriter.write(""); bufferedWriter.close();
                bufferedWriter = new BufferedWriter(new FileWriter("src/Resources/LeaderBoard3.txt",true));
                for (String[] record : records) {
                    bufferedWriter.write(String.join(" ", record));
                    bufferedWriter.newLine();
                }
                File originalFile = new File("src/Resources/LeaderBoard3.txt");
                File sortedFile = new File("src/Resources/temp.txt");
                if (originalFile.delete()) {
                    sortedFile.renameTo(originalFile);
                }
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
            } catch (IOException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }

}


