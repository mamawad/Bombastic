package Test;

import Resources.LeaderBoard;

public class Test {
    public static void main(String[] args){
        /*
        LeaderBoard.addToLeaderBoard(2,"Majd","Moussa",21.22);
        LeaderBoard.addToLeaderBoard(2,"Saad","IQBAL",25.22);
        LeaderBoard.addToLeaderBoard(2,"MOUSSA","Hameed",255.22);
        LeaderBoard.addToLeaderBoard(2,"MOha","Some",285.22);
        LeaderBoard.addToLeaderBoard(2,"you","sef",12);
        */

        String[][] top10 = LeaderBoard.getLeaderBoard(2);
        for(int i = 0; i < top10.length; i++){
            for(int y = 0 ; y < top10[i].length; y++){
                System.out.print(top10[i][y]+" ");
            }
            System.out.println();
        }

    }
}
